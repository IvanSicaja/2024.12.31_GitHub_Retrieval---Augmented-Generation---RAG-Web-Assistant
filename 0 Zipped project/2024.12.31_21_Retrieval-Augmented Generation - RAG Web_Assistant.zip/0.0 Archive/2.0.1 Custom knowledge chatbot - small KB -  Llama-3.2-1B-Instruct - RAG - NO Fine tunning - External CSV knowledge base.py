import os
import spacy
import pandas as pd
import torch
from huggingface_hub import login
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import keyboard  # To detect escape key press

# --------------------------------------------------------------- MODEL DEFINITION --------------------------------------------------------------------------------------
# --- Configure Environment for Windows Symlink Compatibility ---
os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'  # Disable symlink warnings for Windows

# --- Hugging Face Authentication ---
login("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")  # Replace with your Hugging Face token

# --- Setup NLP and LLaMA Model ---
nlp = spacy.load("en_core_web_sm")  # Load spaCy for text preprocessing
tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B-Instruct", token="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")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-3.2-1B-Instruct", token="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").to(device)

# Set up the text generation pipeline with LLaMA model
generator = pipeline("text-generation", model=model, tokenizer=tokenizer, pad_token_id=tokenizer.eos_token_id, device=0 if device == torch.device("cuda") else -1)

# --------------------------------------------------------------- KNOWLEDGE BASE FROM EXCEL --------------------------------------------------------------------------------------
# --- Load Knowledge Base from Excel (.xlsx) ---
xlsx_path = "1.0 Datasets/1.1.0_ENG_Pidriš WEB description_small chunks.xlsx"  # Replace with your actual Excel file path
# Read Excel file
df = pd.read_excel(xlsx_path)
# Assuming the first column of the Excel file contains the text chunks (documents)
documents = df.iloc[:, 0].tolist()

# ------------------------------------------------------------- KNOWLEDGE BASE EMBEDDINGS AND ADDING TO FAISS --------------------------------------------------------------------------------------
# --- Setup Sentence Transformer and FAISS Index ---
model_encoder = SentenceTransformer('all-MiniLM-L6-v2')  # Load SentenceTransformer for embeddings
document_embeddings = model_encoder.encode(documents)  # Generate embeddings for each document

# Initialize FAISS index for fast document retrieval
dimension = document_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(document_embeddings)

# Map document IDs for retrieval
doc_id_map = {i: f"Document {i + 1}" for i in range(len(documents))}
print("Document Embeddings Added to FAISS Index")

# --------------------------------------------------------------- FUNCTIONS DEFINITIONS --------------------------------------------------------------------------------------

# Step 1: Preprocess text for uniformity (for both query and documents)
def preprocess_text(text):
    doc = nlp(text)
    tokens = [token.lemma_.lower() for token in doc if not token.is_stop and not token.is_punct]
    return " ".join(tokens)

# Step 2: Define a function to retrieve the most relevant document based on the user query
def retrieve_document(query):
    processed_query = preprocess_text(query)
    query_embedding = model_encoder.encode([processed_query])

    # Search in FAISS index for the closest document
    k = 3  # Retrieve top 1 most relevant document
    distances, indices = index.search(query_embedding, k)

    # Retrieve the document ID and text
    retrieved_doc_id = indices[0][0]
    return doc_id_map[retrieved_doc_id], documents[retrieved_doc_id]  # Return document name and text

# Step 3: Define function to generate response based on retrieved document
def generate_response(query, use_conversation_history=True):
    # Retrieve the relevant document for context
    retrieved_doc_name, retrieved_doc_text = retrieve_document(query)
    print(f"Retrieved Document: {retrieved_doc_name}")

    # Build context for model
    contextual_input = f"User query: {query}\nDocument context: {retrieved_doc_text}\nAnswer:"

    # Generate response using LLaMA model
    response = generator(
        contextual_input,
        max_new_tokens=512,  # Adjust as necessary
        num_return_sequences=1,
        truncation=True,
        do_sample=True,
        temperature=0.7
    )

    # Extract the answer from the generated text
    generated_text = response[0]["generated_text"]
    if "Answer:" in generated_text:
        generated_text = generated_text.split("Answer:")[-1].strip()
    else:
        generated_text = generated_text.strip()

    return generated_text

# --------------------------------------------------------------- MAIN LOOP --------------------------------------------------------------------------------------

if __name__ == "__main__":
    print("Chatbot ready! Type your questions. Press 'Esc' to exit.")

    while True:
        if keyboard.is_pressed("esc"):
            print("\nExiting chatbot. Goodbye!")
            break

        print("-----------------------------------------------------------------")
        user_query = input("You: ")
        print("User Query:", user_query)

        # Generate and print the response
        chatbot_response = generate_response(user_query)
        print("[FINAL CHATBOT ANSWER]:", chatbot_response)
